#!/bin/bash
#MYDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

/opt/synscan/subnetScan.sh /opt/synscan/geolist/Zall.txt 8080 $1
/opt/synscan/subnetScan.sh /opt/synscan/geolist/Zall.txt 3128 $1

