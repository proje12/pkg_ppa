#!/bin/bash
if [ $# -lt 2 ]; then
  echo "usage: $0 listfile port [configfile]"
fi
set -x
#MYDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

cd /home/synscan/

IFACE=eth0
PPS=980
SUBNETLIST=$1
export PORT=$2
STARTTIME=`date +%Y%m%d%H%M%S`
FILE=`basename "$SUBNETLIST"`
OUTPUT_DIR=/home/synscan/output
CONTROL_PORT=60001
PCAP_DIR=pcaps
PROCESSED_HOSTS=processed.txt
PROCESSED_HOSTS_NEW=processed_new.txt

trap "trap - SIGTERM && kill -- -$$" SIGINT SIGTERM EXIT
if [ ! -z "$3" ]; then
  . $3
fi
mkdir -p $PCAP_DIR
touch $PROCESSED_HOSTS

convert(){
        tcpdump -nn -r $1|fgrep "ack 4294966543" |grep -Po "IP \d+\.\d+\.\d+\.\d+\.\d+"| \
        sed -E 's|IP (.*\..*\..*\..*)\.(.*)|\1:\2|' |sort -u | fgrep -x -v -f $PROCESSED_HOSTS | \
        tee -a $PROCESSED_HOSTS_NEW | xz -z > $1.txt.xz.in_prog
        
        mv $1.txt.xz.in_prog $OUTPUT_DIR/$( basename $1).txt.xz && rm $1
}

move_files(){
#$1 - pocet nepresunutych poslednich souboru minus 1
  MOVE=0
  for file in `ls -t $PCAP_DIR/*_${PORT}.pcap* 2>/dev/null|tail -n +$1`; do
    convert $file
    MOVE=1
  done
  if [ $MOVE == "1" ]; then
    mv $PROCESSED_HOSTS_NEW $PROCESSED_HOSTS
  fi
}

while true; do
        move_files 3
        sleep 300
done &
CONVERT_PID=$!

SRCIP=`ifconfig $IFACE |awk '/inet /{print $2}'`

tcpdump -nn -Z root -i $IFACE "port $PORT and tcp[tcpflags] == (tcp-syn|tcp-ack) and dst host $SRCIP" -C 1 -w "${PCAP_DIR}/${STARTTIME}_${FILE}_${PORT}.pcap" &
TCPDUMP_PID=$!

GWIP=`ip r |grep default|awk '{print $3}'`
DSTMAC=`arp -n|grep "^$GWIP "|awk '{print $3}' | head -1`
java -server -jar "/opt/synscan/synscan.jar" -ack 4294966542 -cp $CONTROL_PORT -f $SUBNETLIST -sl -i $IFACE -pps $PPS -s $SRCIP -dmac $DSTMAC -dport $PORT

sleep 2
kill $TCPDUMP_PID $CONVERT_PID
sleep 2
move_files 0
rm $PROCESSED_HOSTS_NEW $PROCESSED_HOSTS
