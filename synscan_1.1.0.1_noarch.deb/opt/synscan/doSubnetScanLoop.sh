#!/bin/bash

while true; do
/opt/synscan/subnetScan.sh /opt/synscan/geolist/Zall.txt 8080 $1
sleep 2
/opt/synscan/subnetScan.sh /opt/synscan/geolist/Zall.txt 3128 $1
sleep 2
done
