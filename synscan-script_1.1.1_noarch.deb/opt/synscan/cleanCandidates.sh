#!/bin/bash

SORTED=`mktemp`
OK_C=`mktemp`
sort -u $1 > $SORTED
cat $SORTED|awk -F. '{print $1"."$2"."$3"."}' |sort |uniq -c|awk '{if($1<60) print $2}' |sort -u >$OK_C
fgrep -f $OK_C $SORTED |sort -R >$1.cleaned
rm $SORTED $OK_C

