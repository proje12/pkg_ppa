#!/bin/bash

cd "$( dirname "${BASH_SOURCE[0]} )"
PARAMS=synscan.conf

while true; do
  /opt/synscan/subnetScan.sh /opt/synscan/geolist/Zall.txt 8080 $PARAMS
  sleep 2
  /opt/synscan/subnetScan.sh /opt/synscan/geolist/Zall.txt 3128 $PARAMS
  sleep 2
  /opt/synscan/subnetScan.sh /opt/synscan/geolist/port80.txt 80 $PARAMS
  sleep 2
  /opt/synscan/subnetScan.sh /opt/synscan/geolist/northAm.txt 8080 $PARAMS
  sleep 2
  /opt/synscan/subnetScan.sh /opt/synscan/geolist/northAm.txt 3128 $PARAMS
  sleep 2
done
