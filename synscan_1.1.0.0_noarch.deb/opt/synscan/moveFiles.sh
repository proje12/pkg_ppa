#!/bin/bash
set -x
RSYNC_SSH_PARAMS=" -e 'ssh -p 10022'"
SRC="/home/synscan/output/*xz"
DST="azu02:/home/proxyscan/01_input/"


while true; do
  if eval ls "$SRC" 2>/dev/null; then
    eval rsync "$RSYNC_SSH_PARAMS" --remove-source-files -av "$SRC" "$DST"    
  fi
  sleep 300
done
