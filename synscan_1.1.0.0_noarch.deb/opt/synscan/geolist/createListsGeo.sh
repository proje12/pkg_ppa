#!/bin/bash

mkdir -p tmpLists
cd tmpLists
wget -O GeoLite2-Country-CSV.zip 'https://download.maxmind.com/app/geoip_download?edition_id=GeoLite2-Country-CSV&license_key=8dU5XxTZ4trWndJC&suffix=zip'
unzip -o -j GeoLite2-Country-CSV.zip
cd ..

python3 - << EOF
country_file = open("tmpLists/GeoLite2-Country-Locations-en.csv", "r")
zones = [['DE', 'FR', 'JE', 'MC'],
         ['GG', 'LI', 'CH', 'BE', 'DK', 'NL', 'AT', 'LU'],
         ['GB', 'IE', 'IM'],
         ['IS', 'FI', 'SE', 'NO', 'SJ', 'FO', 'AX', 'EU', 'HU', 'PL', 'SK', 'RO', 'BG', 'HR', 'XK', 'SI', 'GR', 'CY',
          'EE', 'LT', 'LV'],
         ['MT', 'ES', 'IT', 'PT', 'GI', 'VA', 'SM', 'AD'],
         ['BY', 'UA', 'RU', 'MD', 'MK', 'RS', 'BA', 'AL', 'ME'],
         ['CZ']]
zones_num = len(zones)
zones_geo_code = [[]]
cidr_lists = [[]]
for i in range(zones_num - 1):
    # prvni list uz je vytvoren, proto zones_num-1
    zones_geo_code.append([])
    #cidr_lists.append([])
for country in country_file:
    country_record = country.split(",", 8)
    if country_record[3] == "Europe":
        country_geo_ident = country_record[0]
        country_iso_code = country_record[4]
        if country_iso_code == '':
            country_iso_code = 'EU'
        i = 0
        for zone in zones:
            if country_iso_code in zone:
                # print("pridavam"+country_geo_ident+" "+str(i))
                zones_geo_code[i].append(country_geo_ident)
                break
            i += 1
        if i >= zones_num:
            print("Not in zones: " + country_iso_code)

#print(zones_geo_code)
country_file.close()

blocks_file = open("tmpLists/GeoLite2-Country-Blocks-IPv4.csv", "r")
out_file=[]
out_file.append(open("Z1_DE_FR.txt", "w"))
out_file.append(open("Z2_West.txt", "w"))
out_file.append(open("Z3_GB.txt", "w"))
out_file.append(open("Z4_mix.txt", "w"))
out_file.append(open("Z5_South.txt", "w"))
out_file.append(open("Z6_notUnion.txt", "w"))
out_file.append(open("Z7_CZ.txt", "w"))

for ip_block in blocks_file:
    block_record = ip_block.split(',', 3)
    cidr = block_record[0]
    if cidr in ["195.113.0.0/16", "147.251.0.0/16"]:
        continue
    country_geo_ident = block_record[1]
    for i in range(zones_num):
        if country_geo_ident in zones_geo_code[i]:
            #cidr_lists[i].append(cidr)
            out_file[i].write(cidr+"\n")
            break
EOF

cat Z?_*.txt > Zall.txt
