#!/bin/bash
if [ $# -lt 2 ]; then
  echo "usage: $0 listfile port [configfile]"
fi
#set -x
#MYDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

PPS=980
SUBNETLIST=$1
PORT=$2
STARTTIME=`date +%Y%m%d%H%M%S`
FILE=`basename "$SUBNETLIST"`
OUTPUT_DIR=output
TMP_DIR=running
MASSCAN=/opt/synscan/masscan

mkdir -p $OUTPUT_DIR $TMP_DIR

trap "trap - SIGTERM && kill -- -$$" SIGINT SIGTERM EXIT
if [ ! -z "$3" ]; then
  . $3
fi

move_files(){
#$1 - pocet nepresunutych poslednich souboru minus 1
  for file in `ls -t $TMP_DIR/*_${PORT}.*.txt 2>/dev/null|tail -n +$1`; do
    cat $file | xz -z > $file.xz.in_prog
    echo "moving `date` $file, `wc -l $file`"
    mv $file.xz.in_prog $OUTPUT_DIR/$(basename $file).xz && rm $file
  done
}

while true; do
        sleep 35
        move_files 2
done &

$MASSCAN --randomize-hosts -p $PORT --include-file $SUBNETLIST --rate $PPS \
 | stdbuf --output=L awk '/^Discovered/{split($4,port, "/"); print $6":"port[1]}' \
 | rotatelogs -l ${TMP_DIR}/${STARTTIME}_${FILE}_${PORT}.%d%H%M.txt 700 

move_files 0
