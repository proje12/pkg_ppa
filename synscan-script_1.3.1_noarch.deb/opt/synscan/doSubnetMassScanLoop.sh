#!/bin/bash

cd "$( dirname "${BASH_SOURCE[0]}" )"
PARAMS=synscan.conf

while true; do
	for i in a b c; do
		for j in 3128 8080; do
			/opt/synscan/subnetMasscan.sh /opt/synscan/geolist/Zall_a${i}.txt $j $PARAMS
			sleep 1
		done
	done	
#  /opt/synscan/subnetScan.sh /opt/synscan/geolist/port80.txt 80 $PARAMS
#  /opt/synscan/subnetScan.sh /opt/synscan/geolist/northAm_aa.txt 8080 $PARAMS
done
