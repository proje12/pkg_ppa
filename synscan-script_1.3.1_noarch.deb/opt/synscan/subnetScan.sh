#!/bin/bash
if [ $# -lt 2 ]; then
  echo "usage: $0 listfile port [configfile]"
fi
set -x
#MYDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

IFACE=eth0
PPS=980
SUBNETLIST=$1
export PORT=$2
STARTTIME=`date +%Y%m%d%H%M%S`
FILE=`basename "$SUBNETLIST"`
OUTPUT_DIR=output
CONTROL_PORT=60001
PCAP_DIR=pcaps
DUP_CHECK_DIR=dupcheck
PROCESSED_HOSTS=processed.txt
PROCESSED_HOSTS_NEW=processed_new.txt

trap "trap - SIGTERM && kill -- -$$" SIGINT SIGTERM EXIT
if [ ! -z "$3" ]; then
  . $3
fi
mkdir -p $PCAP_DIR
mkdir -p $DUP_CHECK_DIR
touch $PROCESSED_HOSTS
touch $DUP_CHECK_DIR/nullfile

move_files(){
#$1 - pocet nepresunutych poslednich souboru minus 1
  for file in `ls -t $PCAP_DIR/*_${PORT}.pcap* 2>/dev/null|tail -n +$1`; do
    cat $DUP_CHECK_DIR/* >$PROCESSED_HOSTS

    tcpdump -nn -r $file|fgrep "ack 4294966543" |grep -Po "IP \d+\.\d+\.\d+\.\d+\.\d+"| \
    sed -E 's|IP (.*\..*\..*\..*)\.(.*)|\1:\2|' |sort -u | fgrep -x -v -f $PROCESSED_HOSTS | \
    tee -a $DUP_CHECK_DIR/$PROCESSED_HOSTS_NEW.$(date +%s) | xz -z > $file.txt.xz.in_prog

    mv $file.txt.xz.in_prog $OUTPUT_DIR/$(basename $file).txt.xz && rm $file
  done
  (cd $DUP_CHECK_DIR; rm $(ls -1t ${PROCESSED_HOSTS_NEW}* |tail -n +15) 2>/dev/null )
}

while true; do
        sleep 120
        move_files 3
done &
CONVERT_PID=$!

SRCIP=`ifconfig $IFACE |awk '/inet /{print $2}'`

tcpdump -nn -Z root -i $IFACE "port $PORT and tcp[tcpflags] == (tcp-syn|tcp-ack) and dst host $SRCIP" -C 1 -w "${PCAP_DIR}/${STARTTIME}_${FILE}_${PORT}.pcap" &
TCPDUMP_PID=$!

GWIP=`ip r |grep default|awk '{print $3}'`

if ifconfig $IFACE | grep -q NOARP; then
  DSTMAC=XXXX
  ISTUN='-tun'
else
  DSTMAC=`arp -n|grep "^$GWIP "|awk '{print $3}' | head -1`
  ISTUN=''
fi

java -server -jar "/opt/synscan/synscan.jar" -ack 4294966542 -cp $CONTROL_PORT -f $SUBNETLIST -sl -i $IFACE -pps $PPS -s $SRCIP $ISTUN -dmac $DSTMAC -dport $PORT
###-el /opt/synscan/exclude.txt

sleep 2
kill $TCPDUMP_PID $CONVERT_PID
sleep 2
move_files 0
rm $PROCESSED_HOSTS
rm $DUP_CHECK_DIR/${PROCESSED_HOSTS_NEW}*
