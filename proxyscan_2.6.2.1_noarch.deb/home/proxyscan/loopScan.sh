#/bin/bash
#takes files from 01_input
#set -x

#MYDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

while true; do
  (cd 01_input/; xz -d *xz 2>/dev/null)
  INPUT_FILE=`ls -tr1 01_input/ |fgrep '.txt' |head -1`
  if [ -z "$INPUT_FILE" ]; then
    sleep 30
    echo -n .
    continue
  fi
  if [ -f proxyscan.env ]; then
    source proxyscan.env
  fi
  cat "01_input/$INPUT_FILE" |fgrep -x -v -f /opt/proxyscan/fuckers.txt | grep -v -E -f /opt/proxyscan/fuckers.subnet.txt |sort -u|sort -R >src.tmp
  echo `date +%Y%m%d%H%M%S` starting ProxySpeedTest
  
  java -Dhttp.keepAlive=false -jar /opt/proxyscan/proxyscan.jar -gd /opt/geolite/GeoLite2-City.mmdb \
    -l src.tmp -mdt 120 -d ${DELAY:-100} -s ${SPEED:-2000000} -r ${RETRY:-1} -st ${SUBMIT_TOUT:-5} \
    -u ${URL:-https://is.muni.cz/elportal/estud/praf/js09/dejiny/web/img/mapy/hq/04.jpg} \
    -json ${JSONOUT:-logs/${INPUT_FILE}_`date +%Y%m%d%H%M%S`.json} -bn ${BATCH_NAME:-loopscan} \
     >logs/${INPUT_FILE}_`date +%Y%m%d%H%M%S`.log 2>&1
  
  echo `date +%Y%m%d%H%M%S` finished ProxySpeedTest
  mv "01_input/$INPUT_FILE" 02_processed/${INPUT_FILE}_`date +%Y%m%d%H%M%S`
done