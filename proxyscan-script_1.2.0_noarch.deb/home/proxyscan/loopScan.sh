#/bin/bash
#takes files from 01_input
#set -x

#MYDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

cd "$( dirname "${BASH_SOURCE[0]}" )" 

files2delay(){
	local FILES_CNT=$1
	local MAX_DELAY=${MAX_DELAY_CONF:-200}
	local MIN_DELAY=${MIN_DELAY_CONF:-25}
	local MIN_THRESH=${MIN_THRESH_CONF:-1}
	local MAX_THRESH=${MAX_THRESH_CONF:-12}

	if [ $FILES_CNT -le $MIN_THRESH ]; then
		echo $MAX_DELAY
	elif [ $FILES_CNT -gt $MIN_THRESH ] && [ $FILES_CNT -lt $MAX_THRESH ]; then
		echo $(($MAX_DELAY-($FILES_CNT-$MIN_THRESH)*($MAX_DELAY-$MIN_DELAY)/($MAX_THRESH-$MIN_THRESH)))
	else
		echo $MIN_DELAY
	fi
}

while true; do
  (cd 01_input/; xz -d *xz 2>/dev/null)
  INPUT_FILE=`ls -tr1 01_input/ |fgrep '.txt' |head -1`
  if [ -z "$INPUT_FILE" ]; then
    sleep 30
    echo -n .
    continue
  fi
  if [ -f proxyscan.env ]; then
    source proxyscan.env
  fi

  DELAY=$( files2delay $(ls 01_input/ | wc -l) )
  echo Delay: $DELAY

  cp /opt/proxyscan/fuckers.txt fuckers.tmp
  dig -t A +short `cat /opt/proxyscan/fuckersDom.txt` |sed 's/\(.*\)/^\1:/g; s/\./\\./g' >>fuckers.tmp
  cat "01_input/$INPUT_FILE" | grep -v -E -f fuckers.tmp |sort -u|sort -R >src.tmp
  echo `date +%Y%m%d%H%M%S` starting ProxySpeedTest
  
  java -Dhttp.keepAlive=false -jar /opt/proxyscan/proxyscan.jar -gd /opt/geolite/GeoLite2-City.mmdb \
    -l src.tmp -mdt 120 -d ${DELAY:-100} -s ${SPEED:-2000000} -r ${RETRY:-1} -st ${SUBMIT_TOUT:-5} \
    -u ${URL:-https://www.sfb1015.uni-freiburg.de/de/img/SFB_Musse_Gruppe.jpg} \
    ${TESTPORT} \
    -json ${JSONOUT:-logs/${INPUT_FILE}_`date +%Y%m%d%H%M%S`.json} -bn ${BATCH_NAME:-loopscan} -ok \
     >logs/${INPUT_FILE}_`date +%Y%m%d%H%M%S`.log 2>&1
  
  echo `date +%Y%m%d%H%M%S` finished ProxySpeedTest
  mv "01_input/$INPUT_FILE" 02_processed/${INPUT_FILE}_`date +%Y%m%d%H%M%S`
done

