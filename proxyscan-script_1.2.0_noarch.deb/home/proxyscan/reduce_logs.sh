#!/bin/bash
mkdir -p /home/proxyscan/logs_reduced
cd /home/proxyscan/logs || exit 1
find /home/proxyscan/logs -type f -mtime +10 -name "*log" -exec grep -E '(DOWN_OK|Submitting)' {}  >../logs_reduced/{} \;
find /home/proxyscan/logs -type f -mtime +11 -name "*log" -delete
find /home/proxyscan/logs -type f -name "*json" -mtime +2 -delete
