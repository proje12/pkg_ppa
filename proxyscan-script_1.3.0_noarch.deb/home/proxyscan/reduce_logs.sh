#!/bin/bash
if [ "`id -u -n`" != "proxyscan" ]; then echo "Run as proxyscan user"; exit 1; fi
mkdir -p /home/proxyscan/logs_reduced
cd /home/proxyscan/logs || exit 1
for i in $(find . -type f -mtime +11 -name "*log"); do grep -E '(DOWN_OK|Submitting)' "$i" >"../logs_reduced/$i" && rm "$i"; done
find /home/proxyscan/logs -type f -name "*json" -mtime +20 -delete
find /home/proxyscan/logs_reduced -type f -name "*log" -mtime +90 -delete
