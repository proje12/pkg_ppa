#!/bin/bash
set -e
cd "$(dirname "$0")"
date >update.txt
wget -O GeoLite2-City.tar.gz 'https://download.maxmind.com/app/geoip_download?edition_id=GeoLite2-City&license_key=8dU5XxTZ4trWndJC&suffix=tar.gz'
tar xzf GeoLite2-City.tar.gz
mv GeoLite2-City_*/GeoLite2-City.mmdb .
rm -rf GeoLite2-City.tar.gz GeoLite2-City_2*
date >>update.txt