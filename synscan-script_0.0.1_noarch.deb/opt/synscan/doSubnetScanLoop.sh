#!/bin/bash

cd /home/synscan
PARAMS=synscan.conf

while true; do
  sed -i 's/PPS=.*/PPS=980/g' $PARAMS
  /opt/synscan/subnetScan.sh /opt/synscan/geolist/Zall.txt 8080 $PARAMS
  sleep 2
  sed -i 's/PPS=.*/PPS=980/g' $PARAMS
  /opt/synscan/subnetScan.sh /opt/synscan/geolist/Zall.txt 3128 $PARAMS
  sleep 2
  sed -i 's/PPS=.*/PPS=1950/g' $PARAMS
  /opt/synscan/subnetScan.sh /opt/synscan/geolist/Zall.txt 80 $PARAMS
  sleep 2
done
